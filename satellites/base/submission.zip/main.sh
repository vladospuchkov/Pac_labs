#!/usr/bin/env bash

DATA_DIR=../data
SUBMISSION_PATH=/code_execution/submission/submission.csv

# call our script (main.py in this case) and tell it where the data is and
python main.py $DATA_DIR $SUBMISSION_PATH